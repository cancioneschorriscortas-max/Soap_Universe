// particles.js — SOAP COSMOS 3D
// ----------------------------------------------------------------------------
//  Mueve N partículas en 3D OBEDECIENDO el campo físico de universe.js (v0.3,
//  intacto). Dos poblaciones, ambas guiadas por la misma física:
//    - ESPUMA  : se asienta en las paredes/filamentos (gradiente de fase)
//    - MATERIA : colapsa en los nodos densos -> cúmulos, galaxias, planetas
//  Verificado por simulación + render antes de integrar.
// ----------------------------------------------------------------------------

export class ParticleField {
  constructor(grid, count){
    this.G = grid;
    this.N = count;
    this.px = new Float32Array(count);
    this.py = new Float32Array(count);
    this.pz = new Float32Array(count);
    this.vx = new Float32Array(count);
    this.vy = new Float32Array(count);
    this.kind = new Uint8Array(count);   // 0 = espuma, 1 = materia
    // buffers de campo log-normalizado (se rellenan cada frame)
    this.logE = new Float32Array(grid*grid);
    this.logD = new Float32Array(grid*grid);
    // salida para Three.js: posiciones y colores
    this.positions = new Float32Array(count*3);
    this.colors    = new Float32Array(count*3);
    this.reset();
  }

  reset(){
    const G=this.G;
    for(let i=0;i<this.N;i++){
      this.px[i]=Math.random()*G;
      this.py[i]=Math.random()*G;
      this.pz[i]=0;
      this.vx[i]=0; this.vy[i]=0;
      this.kind[i]= i < this.N*0.55 ? 0 : 1;   // 55% espuma, 45% materia
    }
  }

  _idx(x,y){
    const G=this.G;
    let xi=x|0, yi=y|0;
    if(xi<0)xi=0; else if(xi>G-1)xi=G-1;
    if(yi<0)yi=0; else if(yi>G-1)yi=G-1;
    return yi*G+xi;
  }

  // Avanza las partículas un paso, leyendo el estado físico de v0.3.
  // state = getState() de universe.js (NO se modifica).
  step(state, substeps=2){
    const G=this.G;
    const { flowX, flowY, energy, density, phase, bhMask } = state;

    // log-normalización de energía y densidad (su rango es enorme)
    let eMax=0, dMax=0;
    for(let i=0;i<G*G;i++){ if(energy[i]>eMax)eMax=energy[i]; if(density[i]>dMax)dMax=density[i]; }
    const le=1/Math.log1p(eMax+1), ld=1/Math.log1p(dMax+1);
    for(let i=0;i<G*G;i++){
      this.logE[i]=Math.log1p(energy[i]>0?energy[i]:0)*le;
      this.logD[i]=Math.log1p(density[i]>0?density[i]:0)*ld;
    }
    const logE=this.logE, logD=this.logD;

    for(let sub=0; sub<substeps; sub++){
      for(let i=0;i<this.N;i++){
        let gx=this.px[i], gy=this.py[i];
        if(gx<2||gx>=G-2||gy<2||gy>=G-2){
          this.px[i]=Math.random()*G; this.py[i]=Math.random()*G;
          this.vx[i]=0; this.vy[i]=0; continue;
        }
        const id=this._idx(gx,gy);
        const e=logE[id];

        if(this.kind[i]===0){
          // ESPUMA: sigue el gradiente de fase (las paredes de la espuma)
          const pgx = phase[this._idx(gx+1,gy)] - phase[this._idx(gx-1,gy)];
          const pgy = phase[this._idx(gx,gy+1)] - phase[this._idx(gx,gy-1)];
          this.vx[i] = this.vx[i]*0.85 + pgx*3.5 + flowX[id]*0.18 + (Math.random()-0.5)*(0.2+e*0.4);
          this.vy[i] = this.vy[i]*0.85 + pgy*3.5 + flowY[id]*0.18 + (Math.random()-0.5)*(0.2+e*0.4);
          this.px[i]+=this.vx[i]*0.4; this.py[i]+=this.vy[i]*0.4;
          this.pz[i]+=((phase[id]*30-15)-this.pz[i])*0.04;
        } else {
          // MATERIA: colapsa hacia los nodos densos (cúmulos/planetas)
          const dHere=logD[id];
          const gradX = logD[this._idx(gx+1,gy)] - logD[this._idx(gx-1,gy)];
          const gradY = logD[this._idx(gx,gy+1)] - logD[this._idx(gx,gy-1)];
          const pull = 7.0*(1.0 - dHere*0.7);   // saturación: no colapsa a 1 punto
          this.vx[i] = this.vx[i]*0.80 + gradX*pull + flowX[id]*0.10 + (Math.random()-0.5)*(0.25+e*0.6);
          this.vy[i] = this.vy[i]*0.80 + gradY*pull + flowY[id]*0.10 + (Math.random()-0.5)*(0.25+e*0.6);
          this.px[i]+=this.vx[i]*0.45; this.py[i]+=this.vy[i]*0.45;
          this.pz[i]+=((logD[id]*70-25)-this.pz[i])*0.05;
        }

        // agujero negro de la física: traga y recicla la partícula
        if(bhMask[id]===1){
          this.px[i]=Math.random()*G; this.py[i]=Math.random()*G;
          this.vx[i]=0; this.vy[i]=0;
        }
      }
    }

    this._writeBuffers(state);
  }

  // Vuelca posiciones/colores al formato que consume Three.js
  _writeBuffers(state){
    const G=this.G, half=G/2;
    const logE=this.logE, logD=this.logD;
    const PL=state.planetMask;
    const pos=this.positions, col=this.colors;

    for(let i=0;i<this.N;i++){
      const id=this._idx(this.px[i], this.py[i]);
      // centrar en el origen, escalar a un cubo agradable
      pos[i*3+0]=(this.px[i]-half)*0.6;
      pos[i*3+1]=this.pz[i]*0.6;
      pos[i*3+2]=(this.py[i]-half)*0.6;

      const e=logE[id], d=logD[id];
      let r,g,b;
      if(PL[id]===1){
        // planeta: ámbar cálido
        r=1.0; g=0.78; b=0.30;
      } else if(this.kind[i]===0){
        // espuma: azul/cian tenue, brilla con la energía
        r=0.12+e*0.25; g=0.45+e*0.45; b=0.80+e*0.20;
        r*=0.6; g*=0.6; b*=0.65;
      } else {
        // materia: de azul a blanco caliente según energía/densidad
        const t=Math.min(1, e*0.6 + d*0.8);
        r=0.30+t*1.5; g=0.55+t*0.4; b=0.95-t*0.45;
      }
      col[i*3+0]=r; col[i*3+1]=g; col[i*3+2]=b;
    }
  }
}
