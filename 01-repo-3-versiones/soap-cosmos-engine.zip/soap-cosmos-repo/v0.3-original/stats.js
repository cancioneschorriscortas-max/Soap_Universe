// stats.js — intacto de la v0.3
export function updateStatsPanel(state) {
  const stats = state._stats || {
    avgEnergy: 0, avgEntropy: 0, avgCurvature: 0,
    foamCount: 0, bhCount: 0, planetCount: 0
  };
  const set=(id,v)=>{ const el=document.getElementById(id); if(el) el.textContent=v; };
  set('energyStat',    stats.avgEnergy.toFixed(3));
  set('entropyStat',   stats.avgEntropy.toFixed(3));
  set('curvatureStat', stats.avgCurvature.toFixed(3));
  set('foamStat',      stats.foamCount);
  set('bhStat',        stats.bhCount);
  set('planetStat',    stats.planetCount);
  set('ageStat',       state.age.toFixed(2));
}
