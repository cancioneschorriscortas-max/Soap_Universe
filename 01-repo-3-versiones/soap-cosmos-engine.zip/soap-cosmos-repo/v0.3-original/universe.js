import { perlin2 } from './noise.js';

const GRID = 180;
const SIZE = GRID * GRID;

let phase, energy, entropy, curvature, density;
let bhMask, planetMask;
let flowX, flowY;
let stress;

let age = 0;
let inflationTime = 0.0;

const idx = (x, y) => y * GRID + x;

export function getState() {
  const planets = [];
  for (let y = 0; y < GRID; y++) {
    for (let x = 0; x < GRID; x++) {
      const i = idx(x, y);
      if (planetMask[i] === 1) {
        planets.push({ x, y });
      }
    }
  }

  return {
    GRID,
    phase,
    energy,
    entropy,
    curvature,
    density,
    bhMask,
    planetMask,
    flowX,
    flowY,
    stress,
    age,
    planets,
    _stats: stats
  };
}

let stats = {};

export function initUniverse() {
  phase = new Float32Array(SIZE);
  energy = new Float32Array(SIZE);
  entropy = new Float32Array(SIZE);
  curvature = new Float32Array(SIZE);
  density = new Float32Array(SIZE);

  bhMask = new Uint8Array(SIZE);
  planetMask = new Uint8Array(SIZE);

  flowX = new Float32Array(SIZE);
  flowY = new Float32Array(SIZE);

  stress = new Float32Array(SIZE);

  age = 0;
  inflationTime = 0.0;

  const cx = GRID / 2;
  const cy = GRID / 2;

  for (let y = 0; y < GRID; y++) {
    for (let x = 0; x < GRID; x++) {
      const d2 = (x - cx) ** 2 + (y - cy) ** 2;
      const e = 65 * Math.exp(-d2 / 180); 
      const i = idx(x, y);

      energy[i] = e;
      phase[i] = e > 1 ? 1 : 0;
    }
  }
}

function lap(field, x, y) {
  return (
    field[idx(x + 1, y)] +
    field[idx(x - 1, y)] +
    field[idx(x, y + 1)] +
    field[idx(x, y - 1)] -
    4 * field[idx(x, y)]
  );
}

function smooth(field, x, y) {
  return (
    field[idx(x, y)] * 0.5 +
    (
      field[idx(x + 1, y)] +
      field[idx(x - 1, y)] +
      field[idx(x, y + 1)] +
      field[idx(x, y - 1)]
    ) * 0.125
  );
}

export function stepUniverse(dt) {
  const nextE = new Float32Array(SIZE);
  const nextP = new Float32Array(SIZE);
  const nextS = new Float32Array(SIZE);
  const nextK = new Float32Array(SIZE);
  const nextD = new Float32Array(SIZE);

  const nextBH = new Uint8Array(SIZE);
  const nextPlanet = new Uint8Array(SIZE);

  let totalE = 0;
  let totalS = 0;
  let totalK = 0;

  let foamCount = 0;
  let bhCount = 0;
  let planetCount = 0;

  const inflFactor = 1 + 0.25 * Math.exp(-inflationTime / 10.0);
  inflationTime += dt * 0.3;

  for (let y = 1; y < GRID - 1; y++) {
    for (let x = 1; x < GRID - 1; x++) {
      const i = idx(x, y);

      let nX = perlin2(x * 0.015 + age * 0.03, y * 0.015);
      let nY = perlin2(x * 0.015, y * 0.015 + 100 + age * 0.03);

      const gradPhaseX = phase[idx(x + 1, y)] - phase[idx(x - 1, y)];
      const gradPhaseY = phase[idx(x, y + 1)] - phase[idx(x, y - 1)];

      flowX[i] = nX * 0.6 + gradPhaseX * 1.8;
      flowY[i] = nY * 0.6 + gradPhaseY * 1.8;
    }
  }

  for (let y = 1; y < GRID - 1; y++) {
    for (let x = 1; x < GRID - 1; x++) {
      const i = idx(x, y);

      if (bhMask[i] === 1) {
        for (let ny = -2; ny <= 2; ny++) {
          for (let nx = -2; nx <= 2; nx++) {
            if (x + nx > 0 && x + nx < GRID - 1 && y + ny > 0 && y + ny < GRID - 1) {
              const neighborIdx = idx(x + nx, y + ny);
              flowX[neighborIdx] += (x - (x + nx)) * 0.15;
              flowY[neighborIdx] += (y - (y + ny)) * 0.15;
            }
          }
        }
      }

      const advect =
        flowX[i] * (energy[idx(x + 1, y)] - energy[idx(x - 1, y)]) * 0.012 +
        flowY[i] * (energy[idx(x, y + 1)] - energy[idx(x, y - 1)]) * 0.012;

      const diff = 0.045 * lap(energy, x, y) * dt;

      const quantum = perlin2(x * 0.04, y * 0.04 + age * 0.2) * 0.025 * dt;

      const damp = -0.002 * energy[i] * dt;
      const localTimeDrag = 1.0 / (1.0 + curvature[i] * 0.15);

      let e = energy[i] * inflFactor + diff + advect + quantum + damp;
      e *= localTimeDrag;

      if (bhMask[i] === 1) e *= 0.1; 
      if (e < 0) e = 0;
      nextE[i] = e;

      const kRaw = Math.abs(lap(phase, x, y));
      const kSmooth = smooth(curvature, x, y) * 0.80 + kRaw * 0.20;
      nextK[i] = kSmooth;

      stress[i] += kSmooth * 0.0012;
      stress[i] *= 0.9985;

      const s = entropy[i] + kSmooth * 0.005 * dt + stress[i] * 0.0025;
      nextS[i] = s;

      let p = phase[i];
      p += diff * 0.18;
      p -= phase[i] * 0.0001;
      p += e * 0.003 - s * 0.0004 - Math.pow(phase[i], 3) * 0.0012;
      p = Math.max(0, Math.min(1, p));
      nextP[i] = p;

      const d = smooth(energy, x, y) * 0.50 + smooth(phase, x, y) * 0.40 + stress[i] * 0.45;
      nextD[i] = d;

      let isBH = 0;
      if (d > 4.0 && kSmooth > 2.6 && e > 1.6) {
        isBH = 1;
      }
      nextBH[i] = isBH;

      let isPlanet = 0;
      if (d > 1.2 && d < 2.8 && kSmooth < 1.4 && e > 0.35 && isBH === 0) {
        isPlanet = 1;
      }
      nextPlanet[i] = isPlanet;

      totalE += e;
      totalS += s;
      totalK += kSmooth;

      if (p > 0.08) foamCount++;
      if (isBH) bhCount++;
      if (isPlanet) planetCount++;
    }
  }

  energy = nextE;
  phase = nextP;
  entropy = nextS;
  curvature = nextK;
  density = nextD;

  bhMask = nextBH;
  planetMask = nextPlanet;

  age += 0.0018 * dt;

  stats = {
    avgEnergy: totalE / SIZE,
    avgEntropy: totalS / SIZE,
    avgCurvature: totalK / SIZE,
    foamCount,
    bhCount,
    planetCount
  };
}
