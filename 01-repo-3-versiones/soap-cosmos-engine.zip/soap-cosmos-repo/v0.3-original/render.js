// render.js — Soap Cosmos Buffering Engine (Versión Final Suave)
let canvas, ctx;
let zoom = 1.0;
let viewMode = 'external';
let focusPlanet = null;

let offscreenCanvas = document.createElement('canvas');
let offscreenCtx = offscreenCanvas.getContext('2d');
let imgData = null;

export function initRender(c, context) {
  canvas = c;
  ctx = context;
}

export function setZoom(z) {
  zoom = z;
}

export function setViewMode(mode) {
  viewMode = mode;
}

export function setFocusPlanet(planet) {
  focusPlanet = planet;
}

export function renderUniverse(state) {
  const { GRID, phase, energy, entropy, curvature, bhMask, planetMask } = state;

  const w = canvas.width;
  const h = canvas.height;

  if (offscreenCanvas.width !== GRID) {
    offscreenCanvas.width = GRID;
    offscreenCanvas.height = GRID;
    imgData = offscreenCtx.createImageData(GRID, GRID);
  }

  const data = imgData.data;

  for (let y = 0; y < GRID; y++) {
    for (let x = 0; x < GRID; x++) {
      const i = y * GRID + x;
      const pixelIdx = i * 4;

      data[pixelIdx]     = 0;
      data[pixelIdx + 1] = 0;
      data[pixelIdx + 2] = 0;
      data[pixelIdx + 3] = 255;

      if (phase[i] < 0.03) continue;

      const e = energy[i];
      const s = entropy[i];
      const k = curvature[i];

      const isBH = bhMask[i] === 1;
      const isPlanet = planetMask[i] === 1;

      if (isBH) {
        data[pixelIdx]     = 255;
        data[pixelIdx + 1] = 255;
        data[pixelIdx + 2] = 255;
        continue;
      }

      if (isPlanet) {
        data[pixelIdx]     = 255;
        data[pixelIdx + 1] = 210;
        data[pixelIdx + 2] = 90;
        continue;
      }

      let r = 0, g = 0, b = 0;

      if (e > 0.4) {
        const mix = Math.min(1.0, (e - 0.4) / 0.45);
        r = Math.floor(0 * (1 - mix) + 0 * mix);
        g = Math.floor(220 * (1 - mix) + 245 * mix);
        b = Math.floor(125 * (1 - mix) + 255 * mix);
      } else if (k > 0.9) {
        const mix = Math.min(1.0, (k - 0.9) / 0.5);
        r = Math.floor(0 * (1 - mix) + 255 * mix);
        g = Math.floor(220 * (1 - mix) + 150 * mix);
        b = Math.floor(125 * (1 - mix) + 0 * mix);
      } else if (s > 1.5) {
        const mix = Math.min(1.0, (s - 1.5) / 1.0);
        r = Math.floor(0 * (1 - mix) + 230 * mix);
        g = Math.floor(220 * (1 - mix) + 0 * mix);
        b = Math.floor(125 * (1 - mix) + 100 * mix);
      } else {
        r = 0; g = 220; b = 125;
      }

      data[pixelIdx]     = r;
      data[pixelIdx + 1] = g;
      data[pixelIdx + 2] = b;
    }
  }

  offscreenCtx.putImageData(imgData, 0, 0);

  ctx.globalCompositeOperation = "source-over";
  ctx.fillStyle = "rgba(0, 0, 0, 0.3)";
  ctx.fillRect(0, 0, w, h);

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";

  const cellSize = Math.min(w, h) / GRID * zoom;
  let centerX = GRID / 2;
  let centerY = GRID / 2;

  if (viewMode === 'internal' && focusPlanet) {
    centerX = focusPlanet.x;
    centerY = focusPlanet.y;
  }

  const renderW = GRID * cellSize;
  const renderH = GRID * cellSize;
  const renderX = w / 2 - centerX * cellSize;
  const renderY = h / 2 - centerY * cellSize;

  ctx.drawImage(offscreenCanvas, renderX, renderY, renderW, renderH);
}
