// ui.js
let timeFactor = 1.0;
let viewMode = 'external';

export function initUI({ onToggle, onReset, onZoomChange, onViewModeChange }) {
  const toggleBtn = document.getElementById('toggleBtn');
  const resetBtn = document.getElementById('resetBtn');
  const timeSlider = document.getElementById('timeFactor');
  const timeLabel = document.getElementById('timeFactorLabel');
  const zoomSlider = document.getElementById('zoom');
  const zoomLabel = document.getElementById('zoomLabel');
  const viewBtn = document.getElementById('viewModeBtn');

  toggleBtn.addEventListener('click', () => {
    onToggle();
    toggleBtn.textContent = toggleBtn.textContent === 'Pausar' ? 'Reanudar' : 'Pausar';
  });

  resetBtn.addEventListener('click', () => {
    onReset();
  });

  timeSlider.addEventListener('input', () => {
    timeFactor = parseFloat(timeSlider.value);
    timeLabel.textContent = timeFactor.toFixed(1) + 'x';
  });

  zoomSlider.addEventListener('input', () => {
    const z = parseFloat(zoomSlider.value);
    zoomLabel.textContent = z.toFixed(1) + 'x';
    onZoomChange(z);
  });

  viewBtn.addEventListener('click', () => {
    viewMode = viewMode === 'external' ? 'internal' : 'external';
    viewBtn.textContent = viewMode === 'external' ? 'Vista interna' : 'Vista externa';

    if (viewMode === 'internal') {
      zoomSlider.value = 1.0;
      onZoomChange(1.0);
    }

    onViewModeChange(viewMode);
  });
}

export function getTimeFactor() {
  return timeFactor;
}

export function getViewMode() {
  return viewMode;
}
