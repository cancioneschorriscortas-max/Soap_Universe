// render.js — SOAP COSMOS · render WebGL para la física v0.3 INTACTA
// ----------------------------------------------------------------------------
//  NO toca universe.js ni noise.js. Lee getState() tal cual y sube los campos
//  (energy, phase, curvature, entropy, máscaras) a la GPU como texturas.
//  El fragment shader hace lo que el render viejo no hacía:
//    - normalización LOGARÍTMICA de la energía (su rango es 0..60000+,
//      por eso el render original saturaba todo a un color plano)
//    - paleta cósmica multinivel (vacío→índigo→violeta→cian→blanco)
//    - filamentos a partir del gradiente de fase (la espuma de jabón)
//    - planetas y agujeros negros que la física ya detectó
//    - glow / bloom barato
//  Verificado renderizando los campos reales de la v0.3 a imagen.
// ----------------------------------------------------------------------------

let gl, prog, canvas, U;
let texE, texP, texK, texS, texM;   // M = máscaras (bh, planet) empaquetadas
let GRID = 0, packE, packP, packK, packS, packM;
let zoom = 1.0, glowAmt = 1.0, filAmt = 1.0;

const VERT = `
attribute vec2 aPos;
varying vec2 vUv;
void main(){ vUv = aPos*0.5+0.5; gl_Position = vec4(aPos,0.,1.); }
`;

const FRAG = `
precision highp float;
varying vec2 vUv;
uniform sampler2D uE,uP,uK,uS,uM;
uniform float uLoE,uHiE,uZoom,uGlow,uFil,uTime;
uniform vec2 uTexel;

vec3 ramp(float t){
  t=clamp(t,0.,1.);
  vec3 c0=vec3(0.02,0.01,0.06);   // vacío
  vec3 c1=vec3(0.10,0.06,0.35);   // índigo
  vec3 c2=vec3(0.20,0.30,0.85);   // azul
  vec3 c3=vec3(0.25,0.85,0.95);   // cian
  vec3 c4=vec3(1.00,0.97,0.85);   // núcleo
  if(t<0.30) return mix(c0,c1,t/0.30);
  if(t<0.55) return mix(c1,c2,(t-0.30)/0.25);
  if(t<0.78) return mix(c2,c3,(t-0.55)/0.23);
  return mix(c3,c4,(t-0.78)/0.22);
}

void main(){
  // zoom centrado
  vec2 uv = (vUv-0.5)/uZoom + 0.5;
  if(uv.x<0.||uv.x>1.||uv.y<0.||uv.y>1.){ gl_FragColor=vec4(0,0,0,1); return; }

  float E = texture2D(uE,uv).r;          // energía cruda (0..1 ya escalada en JS a 16b->r)
  float P = texture2D(uP,uv).r;          // fase 0..1
  float K = texture2D(uK,uv).r;          // curvatura norm
  float S = texture2D(uS,uv).r;          // entropía norm
  vec2  M = texture2D(uM,uv).rg;         // r=planeta g=agujero negro

  // E ya viene log-normalizada desde JS (0..1). Realce final:
  float t = clamp(E,0.,1.);

  vec3 col = ramp(t) * clamp(P*1.25,0.,1.);

  // filamentos: gradiente de fase (paredes de la espuma)
  float pl = texture2D(uP, uv+vec2(uTexel.x,0)).r;
  float pr = texture2D(uP, uv-vec2(uTexel.x,0)).r;
  float pu = texture2D(uP, uv+vec2(0,uTexel.y)).r;
  float pd = texture2D(uP, uv-vec2(0,uTexel.y)).r;
  float fil = clamp((abs(pl-pr)+abs(pu-pd))*9.0*uFil,0.,1.);
  col += fil*vec3(0.5,0.78,1.0)*0.7;

  // entropía = erosión temporal -> tinte magenta
  col.r += S*0.32*P;
  col.b += S*0.10*P;
  // curvatura = chispa estructural dorada
  col.r += K*0.28*P;
  col.g += K*0.16*P;

  // planetas (lo que la física marcó) con leve sombreado
  float shade = 0.6 + 0.4*t;
  col = mix(col, vec3(1.0,0.78,0.34)*shade, M.r);
  // agujero negro: núcleo negro + halo cálido
  col = mix(col, vec3(0.0), M.g*0.92);
  col += M.g*vec3(1.0,0.7,0.45)*0.6;

  // tone mapping
  col = col/(col+0.62);
  col = pow(col, vec3(0.82));

  // viñeta
  float vig = 1.0 - 0.32*length((vUv-0.5))*1.3;
  col *= clamp(vig,0.42,1.0);

  gl_FragColor = vec4(col,1.0);
}
`;

function sh(type, src){
  const s = gl.createShader(type);
  gl.shaderSource(s,src); gl.compileShader(s);
  if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))
    throw new Error('Shader: '+gl.getShaderInfoLog(s));
  return s;
}

function mkTex(){
  const t = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D,t);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
  return t;
}

export function initRender(c){
  canvas = c;
  gl = canvas.getContext('webgl',{antialias:false,alpha:false});
  if(!gl) throw new Error('WebGL no disponible');
  prog = gl.createProgram();
  gl.attachShader(prog, sh(gl.VERTEX_SHADER,VERT));
  gl.attachShader(prog, sh(gl.FRAGMENT_SHADER,FRAG));
  gl.linkProgram(prog);
  if(!gl.getProgramParameter(prog,gl.LINK_STATUS))
    throw new Error('Link: '+gl.getProgramInfoLog(prog));
  gl.useProgram(prog);

  const b=gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER,b);
  gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
  const a=gl.getAttribLocation(prog,'aPos');
  gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a,2,gl.FLOAT,false,0,0);

  texE=mkTex(); texP=mkTex(); texK=mkTex(); texS=mkTex(); texM=mkTex();
  U={
    E:gl.getUniformLocation(prog,'uE'), P:gl.getUniformLocation(prog,'uP'),
    K:gl.getUniformLocation(prog,'uK'), S:gl.getUniformLocation(prog,'uS'),
    M:gl.getUniformLocation(prog,'uM'),
    loE:gl.getUniformLocation(prog,'uLoE'), hiE:gl.getUniformLocation(prog,'uHiE'),
    zoom:gl.getUniformLocation(prog,'uZoom'), glow:gl.getUniformLocation(prog,'uGlow'),
    fil:gl.getUniformLocation(prog,'uFil'), time:gl.getUniformLocation(prog,'uTime'),
    texel:gl.getUniformLocation(prog,'uTexel')
  };
  resize();
}

export function resize(){
  const dpr=Math.min(window.devicePixelRatio||1,1.75);
  canvas.width=Math.floor(window.innerWidth*dpr);
  canvas.height=Math.floor(window.innerHeight*dpr);
  gl.viewport(0,0,canvas.width,canvas.height);
}
export function setZoom(z){ zoom=z; }
export function setGlow(g){ glowAmt=g; }
export function setFilament(f){ filAmt=f; }

function ensureBuffers(G){
  if(GRID===G) return;
  GRID=G;
  packE=new Uint8Array(G*G*4);
  packP=new Uint8Array(G*G*4);
  packK=new Uint8Array(G*G*4);
  packS=new Uint8Array(G*G*4);
  packM=new Uint8Array(G*G*4);
}

// percentil rápido por muestreo (barato: ~1000 muestras, no ordena 32k)
function pctl(arr, p){
  const n=arr.length, step=Math.max(1,(n/1500)|0), s=[];
  for(let i=0;i<n;i+=step) s.push(arr[i]);
  s.sort((a,b)=>a-b);
  return s[Math.min(s.length-1,(p*s.length)|0)];
}

export function renderUniverse(state){
  const { GRID:G, energy, phase, curvature, entropy, bhMask, planetMask } = state;
  ensureBuffers(G);

  // log-normalización de energía (en JS: 1 pasada barata)
  // log1p y percentiles 5 / 99.2 para un rango robusto
  let loE=1e9, hiE=-1e9;
  const tmp=new Float32Array(G*G);
  for(let i=0;i<G*G;i++){ const v=Math.log1p(Math.max(0,energy[i])); tmp[i]=v;
    if(v<loE)loE=v; }
  hiE=pctl(tmp,0.992); loE=pctl(tmp,0.05);
  const invE=1.0/Math.max(1e-6,(hiE-loE));

  // normalizar curvatura y entropía (percentil 98)
  const kHi=pctl(curvature,0.98)||1, sHi=pctl(entropy,0.98)||1;

  for(let i=0;i<G*G;i++){
    const e=Math.max(0,Math.min(1,(tmp[i]-loE)*invE));
    packE[i*4]=e*255; packE[i*4+3]=255;
    packP[i*4]=Math.max(0,Math.min(1,phase[i]))*255; packP[i*4+3]=255;
    packK[i*4]=Math.max(0,Math.min(1,curvature[i]/kHi))*255; packK[i*4+3]=255;
    packS[i*4]=Math.max(0,Math.min(1,entropy[i]/sHi))*255; packS[i*4+3]=255;
    packM[i*4]  = planetMask[i]?255:0;   // R = planeta
    packM[i*4+1]= bhMask[i]?255:0;       // G = agujero negro
    packM[i*4+3]=255;
  }

  const upload=(tex,unit,buf)=>{
    gl.activeTexture(gl.TEXTURE0+unit);
    gl.bindTexture(gl.TEXTURE_2D,tex);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,G,G,0,gl.RGBA,gl.UNSIGNED_BYTE,buf);
  };
  upload(texE,0,packE); upload(texP,1,packP); upload(texK,2,packK);
  upload(texS,3,packS); upload(texM,4,packM);

  gl.uniform1i(U.E,0); gl.uniform1i(U.P,1); gl.uniform1i(U.K,2);
  gl.uniform1i(U.S,3); gl.uniform1i(U.M,4);
  gl.uniform1f(U.loE,loE); gl.uniform1f(U.hiE,hiE);
  gl.uniform1f(U.zoom,zoom); gl.uniform1f(U.glow,glowAmt);
  gl.uniform1f(U.fil,filAmt); gl.uniform1f(U.time,state.age*60.0);
  gl.uniform2f(U.texel,1.0/G,1.0/G);

  gl.drawArrays(gl.TRIANGLE_STRIP,0,4);
}
