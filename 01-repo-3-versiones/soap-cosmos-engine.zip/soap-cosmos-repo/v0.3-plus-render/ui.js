// ui.js — controles. No toca la física; sólo pausa/reset y ajustes de render.
let timeFactor = 1.0;

export function initUI({ onToggle, onReset, onZoom, onGlow, onFil }){
  const $=id=>document.getElementById(id);
  const tb=$('toggleBtn');
  tb.addEventListener('click',()=>{ onToggle(); tb.textContent = tb.textContent==='Pausar'?'Reanudar':'Pausar'; });
  $('resetBtn').addEventListener('click', onReset);

  const ts=$('timeFactor'), tl=$('timeFactorLabel');
  ts.addEventListener('input',()=>{ timeFactor=parseFloat(ts.value); tl.textContent=timeFactor.toFixed(1)+'x'; });

  const zs=$('zoom'), zl=$('zoomLabel');
  zs.addEventListener('input',()=>{ const z=parseFloat(zs.value); zl.textContent=z.toFixed(1)+'x'; onZoom(z); });

  const gs=$('glow'), glb=$('glowLabel');
  if(gs) gs.addEventListener('input',()=>{ const g=parseFloat(gs.value); glb.textContent=g.toFixed(2); onGlow(g); });

  const fs=$('fil'), fl=$('filLabel');
  if(fs) fs.addEventListener('input',()=>{ const f=parseFloat(fs.value); fl.textContent=f.toFixed(2); onFil(f); });
}
export function getTimeFactor(){ return timeFactor; }
