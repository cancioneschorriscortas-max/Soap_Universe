# 🧼 SOAP COSMOS ENGINE

> ¿Y si el universo se hubiera formado como la espuma de una pastilla de
> jabón que cae? Estamos dentro de la espuma. La espuma es el espacio-tiempo.

Simulador del cosmos basado en una premisa: un jabón impacta contra una
superficie, la espuma que cae crea un universo. La estructura a gran escala
del universo real se llama, literalmente, **"espuma cósmica"** (*cosmic
foam* / Voronoi foam, van de Weygaert) — así que la idea tiene fundamento
físico de verdad, no es solo estética.

---

## 🌌 Versiones

Este repo guarda las tres etapas del proyecto. Cada una funciona por sí
sola y cuenta una parte del viaje.

### `v0.3-original/`
El motor original. **Física real**: un campo continuo en una rejilla de
180×180 que evoluciona con difusión, advección, fases no lineales,
entropía y curvatura. Los planetas y agujeros negros **emergen** de las
ecuaciones, no están scripteados. El render es básico (Canvas 2D, umbrales
fijos de color) y se ve a baja resolución, pero la física es legítima.

### `v0.3-plus-render/`
**La misma física, sin tocar una línea.** Solo se reescribió la capa de
render a WebGL: normalización logarítmica de la energía (su rango va de 0
a ~60.000, por eso el render viejo saturaba a un color plano), paleta
cósmica multinivel, filamentos a partir del gradiente de fase, glow.
Demuestra que el problema visual de v0.3 era el render, no la física.

### `v1.0-particles-3d/`
**La física v0.3 intacta + 60.000 partículas 3D que la obedecen.**
Construido en Three.js con cámara orbitable. Dos poblaciones de
partículas guiadas por el campo físico real:
- **Espuma** → sigue el gradiente de fase (las paredes de la espuma)
- **Materia** → colapsa en los nodos densos → cúmulos, galaxias, planetas

Las partículas no inventan nada: leen el estado de la física cada frame
y se mueven según él. Los agujeros negros de la física reciclan
partículas. El núcleo dorado central es el impacto inicial del jabón.

---

## 🚀 Cómo ejecutar

Todas las versiones usan módulos ES (`import`/`export`), así que **no se
abren con doble clic** (bloqueo CORS de `file://`). Necesitas un servidor
local. Con XAMPP:

1. Copia la carpeta de la versión que quieras a `xampp/htdocs/`
2. Arranca Apache
3. Abre `http://localhost/<carpeta>/`

(O cualquier servidor: `python3 -m http.server`, Live Server de VS Code, etc.)

`v1.0-particles-3d` carga Three.js por CDN — necesita internet la 1ª vez.

---

## 🔬 `research/`

Capturas reales del proceso de desarrollo, en orden. Documentan
visualmente por qué cada versión evolucionó. Útil para entender (o
recordar) las decisiones de diseño al retomar el proyecto.

---

## 🛠️ Para retocar otro día

El cambio físico con más retorno está identificado y pendiente: el umbral
de detección de planetas en `universe.js`
(`if (d > 1.2 && d < 2.8 ...)`) marca **regiones enormes**, no cuerpos.
Ajustarlo para que detecte solo núcleos densos haría que los planetas
fueran cuerpos definidos en vez de manchas. Es una línea, es física de
verdad, y es el siguiente paso natural.

Todo lo cosmético (colores, densidad de cúmulos, grosor de filamentos)
vive en `render.js` / `particles.js`. La física (`universe.js`,
`noise.js`) es sagrada: no se toca salvo para ese umbral.

**Método recomendado al retomarlo:** no te fíes del primer resultado.
Ejecuta la física real, vuelca el estado, renderízalo y *míralo* antes de
darlo por bueno. Ese fue el patrón que funcionó.

---

## 🙏 Créditos e inspiración

- **Física y concepto original**: propios (motor de espuma cósmica v0.3).
- **Arquitectura de partículas GPU en Three.js**: inspirada por
  [Sanjays2402/ai-particle-simulator](https://github.com/Sanjays2402/ai-particle-simulator)
  (MIT) — no se reutilizó su código; sirvió para confirmar que la vía
  correcta eran partículas en GPU, no solvers de fluidos.
- **Fundamento científico**: modelo de espuma cósmica / teselación de
  Voronoi (R. van de Weygaert et al.).

## 📄 Licencia

MIT — ver [LICENSE](LICENSE).
